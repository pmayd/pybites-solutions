def sum_numbers(numbers=None):
    if numbers:
        return sum(numbers)
        
    return sum(range(101))